import SwiftUI

struct Entry: Identifiable, Codable {
    var id = UUID()
    var name = "演示收款人"
    var amount = "0.10"
    var bank = "示例银行"
    var tail = "0000"
    var created = "2026-10-10 14:11:03"
    var submitted = "10-10 14:11"
    var processing = "10-10 14:11"
    var completed = "10-10 14:12"
    var state = "处理中"
    var method = "账户余额"
    var category = "转账红包"
    var note = "转账"
    var explanation = "此处展示模拟处理进度，不产生真实交易。"
    var reward = "1"
}

struct DemoData: Codable {
    var nickname = "示例用户"
    var phone = "156******09"
    var clock = "15:12"
    var points = "117"
    var balance = "1000.00"
    var assets = "1000.00"
    var month = "2026年10月"
    var expense = "2759.38"
    var income = "1000.00"
    var saved = "3.01"
    var entries = [Entry()]
}

final class Store: ObservableObject {
    @Published var data: DemoData {
        didSet {
            if let bytes = try? JSONEncoder().encode(data) {
                UserDefaults.standard.set(bytes, forKey: "ledger-demo-v1")
            }
        }
    }
    init() {
        if let bytes = UserDefaults.standard.data(forKey: "ledger-demo-v1"),
           let saved = try? JSONDecoder().decode(DemoData.self, from: bytes) {
            data = saved
        } else { data = DemoData() }
    }
}

@main struct LedgerDemoApp: App {
    @StateObject private var store = Store()
    var body: some Scene {
        WindowGroup {
            RootView().environmentObject(store).preferredColorScheme(.light)
        }
    }
}

let demoPageBackground = Color(red: 0.95, green: 0.96, blue: 0.97)

struct DemoBadge: View {
    var body: some View {
        Text("模拟演示 · 非交易凭证")
            .font(.system(size: 13, weight: .bold)).foregroundColor(.white)
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(Color(red: 0.16, green: 0.25, blue: 0.40))
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .accessibilityLabel("模拟演示，非交易凭证")
    }
}

struct RootView: View {
    @EnvironmentObject var store: Store
    @State private var editProfile = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    HStack {
                        Text("演示时间 \(store.data.clock)").font(.caption).foregroundColor(.secondary)
                        Spacer()
                        Button { editProfile = true } label: { Image(systemName: "gearshape") }
                    }.padding(.horizontal, 20)
                    HStack(spacing: 15) {
                        Image(systemName: "person.crop.square.fill").font(.system(size: 58)).foregroundColor(.blue)
                        VStack(alignment: .leading, spacing: 8) {
                            Text(store.data.nickname).font(.title2)
                            Text(store.data.phone).font(.subheadline).foregroundColor(.blue)
                        }
                        Spacer()
                        Image(systemName: "chevron.right").foregroundColor(.secondary)
                    }.padding(20).onTapGesture { editProfile = true }
                    VStack(spacing: 0) {
                        menu("会员", icon: "crown.fill", subtitle: "\(store.data.points)积分", color: .orange)
                        Divider().padding(.leading, 50)
                        menu("商家服务", icon: "storefront.fill", subtitle: "演示功能")
                    }.card()
                    NavigationLink {
                        BillsView()
                    } label: { menu("账单", icon: "list.bullet.rectangle.fill") }.buttonStyle(.plain).card()
                    VStack(spacing: 0) {
                        menu("总资产", icon: "chart.pie.fill", subtitle: store.data.assets)
                        Divider().padding(.leading, 50)
                        menu("余额", icon: "yensign.circle.fill", subtitle: store.data.balance)
                        Divider().padding(.leading, 50)
                        menu("余额理财", icon: "leaf.fill", color: .orange)
                        Divider().padding(.leading, 50)
                        menu("信用服务", icon: "checkmark.seal.fill")
                    }.card().onTapGesture { editProfile = true }
                    VStack(alignment: .leading, spacing: 22) {
                        Text("金融服务").font(.headline)
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 4), spacing: 24) {
                            ForEach(["保险", "贷款", "信用", "银行卡", "理财", "经营贷", "银行", "信用卡"], id: \.self) { title in
                                VStack(spacing: 8) {
                                    Image(systemName: "square.stack.3d.up.fill").font(.title).foregroundColor(.blue)
                                    Text(title).font(.subheadline)
                                }
                            }
                        }
                    }.padding(18).card()
                    VStack(alignment: .leading, spacing: 18) {
                        Text("我的民生保障").font(.headline)
                        HStack { ForEach(["医保", "社保", "公积金", "就业"], id: \.self) { title in
                            VStack { Image(systemName: "heart.circle.fill").font(.title).foregroundColor(.blue); Text(title).font(.subheadline) }.frame(maxWidth: .infinity)
                        } }
                    }.padding(18).card()
                    Text("账单实验室：全部数据仅保存在本机，点击资料和资产区域可编辑。")
                        .font(.caption).foregroundColor(.secondary).padding()
                }.padding(.horizontal, 12).padding(.bottom, 20)
            }.background(demoPageBackground).navigationTitle("我的").navigationBarTitleDisplayMode(.inline)
                .sheet(isPresented: $editProfile) { ProfileEditor(data: $store.data) }
        }.safeAreaInset(edge: .bottom, alignment: .trailing) { DemoBadge().padding(.trailing, 12).padding(.vertical, 8) }
    }
    func menu(_ title: String, icon: String, subtitle: String = "", color: Color = .blue) -> some View {
        HStack(spacing: 15) {
            Image(systemName: icon).font(.title2).foregroundColor(color).frame(width: 28)
            Text(title).font(.title3)
            Spacer()
            Text(subtitle).font(.subheadline).foregroundColor(.secondary)
            Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
        }.padding(18)
    }
}

extension View {
    func card() -> some View { self.background(.white).clipShape(RoundedRectangle(cornerRadius: 18)) }
}

struct ProfileEditor: View {
    @Binding var data: DemoData
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            Form {
                Section("个人资料") {
                    TextField("昵称", text: $data.nickname)
                    TextField("手机号", text: $data.phone)
                    TextField("演示时间", text: $data.clock)
                    TextField("会员积分", text: $data.points)
                }
                Section("演示资产") {
                    TextField("余额", text: $data.balance)
                    TextField("总资产", text: $data.assets)
                }
                Section("账单汇总") {
                    TextField("月份", text: $data.month)
                    TextField("支出", text: $data.expense)
                    TextField("收入", text: $data.income)
                    TextField("节省", text: $data.saved)
                }
            }.navigationTitle("编辑演示资料").toolbar { Button("完成") { dismiss() } }
        }
    }
}

struct BillsView: View {
    @EnvironmentObject var store: Store
    @State private var search = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                filterChips
                summaryHeader
                billRows
                Text("进入详情后点击“编辑”；新增账单后可立即编辑。")
                    .font(.caption).foregroundColor(.secondary)
            }.padding(14)
        }
        .background(demoPageBackground)
        .navigationTitle("账单")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $search, prompt: "搜索收款人")
        .toolbar {
            Button { store.data.entries.append(Entry()) } label: {
                Image(systemName: "plus")
            }
        }
    }

    private var filterChips: some View {
        HStack {
            ForEach(["全部", "支出", "转账", "退款"], id: \.self) { item in
                Text(item)
                    .font(.subheadline)
                    .foregroundColor(item == "全部" ? Color.blue : Color.secondary)
                    .padding(12).background(Color.white).clipShape(Capsule())
            }
        }
    }

    private var summaryHeader: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(store.data.month).font(.title2).bold()
            Text("支出 \(store.data.expense)   收入 \(store.data.income)   省 \(store.data.saved)")
                .font(.caption).foregroundColor(.secondary)
        }
    }

    private var billRows: some View {
        VStack(spacing: 0) {
            ForEach($store.data.entries) { entryBinding in
                if matchesSearch(entryBinding.wrappedValue) {
                    NavigationLink {
                        DetailView(entry: entryBinding)
                    } label: {
                        BillRow(entry: entryBinding.wrappedValue)
                    }.buttonStyle(.plain)
                    Divider().padding(.leading, 66)
                }
            }
        }.card()
    }

    private func matchesSearch(_ entry: Entry) -> Bool {
        search.isEmpty || entry.name.localizedCaseInsensitiveContains(search)
    }
}

struct BillRow: View {
    let entry: Entry

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "building.columns.fill")
                .foregroundColor(.teal).font(.title2).frame(width: 36)
            VStack(alignment: .leading, spacing: 10) {
                Text("转账到银行卡-\(entry.name)").foregroundColor(.primary).lineLimit(1)
                Text(entry.category).font(.subheadline).foregroundColor(.secondary)
                Text(entry.created).font(.caption).foregroundColor(.secondary)
            }
            Spacer(minLength: 4)
            VStack(alignment: .trailing, spacing: 10) {
                Text("-\(entry.amount)").font(.title3).bold().foregroundColor(.primary)
                Text(entry.state).font(.subheadline)
                    .foregroundColor(entry.state == "处理中" ? Color.orange : Color.secondary)
            }
        }.padding(18)
    }
}

struct DetailView: View {
    @Binding var entry: Entry
    @State private var editing = false
    var body: some View {
        ScrollView {
            VStack(spacing: 14) {
                VStack(spacing: 18) {
                    Image(systemName: "building.columns.circle.fill").font(.system(size: 52)).foregroundColor(.teal).padding(.top, 18)
                    Text(entry.name).font(.title3)
                    Text("-\(entry.amount)").font(.system(size: 44, weight: .bold))
                    Text(entry.state).font(.title3).foregroundColor(.orange).padding(.bottom, 18)
                    info("创建时间", entry.created)
                    info("付款方式", entry.method)
                    info("转账到", "\(entry.bank)（\(entry.tail)）\(entry.name)")
                    HStack(alignment: .top) {
                        Text("处理进度").foregroundColor(.secondary).frame(width: 85, alignment: .leading)
                        VStack(alignment: .leading, spacing: 18) {
                            step("提交银行处理", time: entry.submitted, active: true)
                            step(entry.state == "失败" ? "处理失败" : "银行处理中", time: entry.processing, active: true)
                            step("银行入账成功", time: entry.state == "成功" ? entry.completed : "", active: entry.state == "成功")
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                    info("进度说明", entry.explanation, color: .orange)
                    info("转账说明", entry.note)
                    info("温馨提示", "模拟数据，不作为转账或银行入账凭证。", color: .orange)
                    info("支付奖励", "演示积分 \(entry.reward)", color: .orange)
                }.padding(16).card()
                VStack(alignment: .leading, spacing: 20) {
                    Text("账单管理").font(.headline)
                    info("账单分类", entry.category)
                }.padding(18).card()
            }.padding(12)
        }.background(demoPageBackground).navigationTitle("账单详情").navigationBarTitleDisplayMode(.inline)
            .toolbar { Button("编辑") { editing = true } }
            .sheet(isPresented: $editing) { EntryEditor(entry: $entry) }
    }
    func info(_ label: String, _ value: String, color: Color = .primary) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text(label).foregroundColor(.secondary).frame(width: 85, alignment: .leading)
            Text(value).foregroundColor(color).frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
        }.font(.system(size: 15)).padding(.vertical, 4)
    }
    func step(_ title: String, time: String, active: Bool) -> some View {
        HStack(alignment: .top) {
            Image(systemName: active ? "checkmark.circle.fill" : "clock.fill").foregroundColor(active ? .blue : .gray)
            VStack(alignment: .leading, spacing: 6) {
                Text(title).foregroundColor(active ? .primary : .secondary)
                if !time.isEmpty { Text(time).font(.caption).foregroundColor(.secondary) }
            }
        }
    }
}

struct EntryEditor: View {
    @Binding var entry: Entry
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            Form {
                Section("交易演示数据") {
                    TextField("收款人", text: $entry.name)
                    TextField("金额（不含负号）", text: $entry.amount).keyboardType(.decimalPad)
                    TextField("银行名称", text: $entry.bank)
                    TextField("卡号尾号", text: $entry.tail).keyboardType(.numberPad)
                    TextField("付款方式", text: $entry.method)
                    Picker("状态", selection: $entry.state) {
                        ForEach(["处理中", "成功", "失败", "已关闭"], id: \.self) { Text($0) }
                    }
                }
                Section("时间（可自由输入）") {
                    TextField("创建时间", text: $entry.created)
                    TextField("提交银行时间", text: $entry.submitted)
                    TextField("处理时间", text: $entry.processing)
                    TextField("入账时间", text: $entry.completed)
                }
                Section("其他内容") {
                    TextField("进度说明", text: $entry.explanation, axis: .vertical)
                    TextField("转账说明", text: $entry.note)
                    TextField("账单分类", text: $entry.category)
                    TextField("奖励积分", text: $entry.reward)
                }
                Section { Text("修改会自动保存到本机。右下角的演示标识固定显示。") }
            }.navigationTitle("编辑账单").toolbar { Button("完成") { dismiss() } }
        }
    }
}
