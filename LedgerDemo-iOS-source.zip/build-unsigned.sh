#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
xcodebuild -project LedgerDemo.xcodeproj -scheme LedgerDemo -configuration Release -sdk iphoneos -derivedDataPath build CODE_SIGNING_ALLOWED=NO build
mkdir -p output/Payload
rm -rf output/Payload/LedgerDemo.app
cp -R build/Build/Products/Release-iphoneos/LedgerDemo.app output/Payload/
cd output
rm -f LedgerDemo-unsigned.ipa
zip -r LedgerDemo-unsigned.ipa Payload
